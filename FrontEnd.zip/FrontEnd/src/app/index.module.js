(function() {
  'use strict';

  angular
    .module('ohax', ['ui.router', 'toastr']);

})();
